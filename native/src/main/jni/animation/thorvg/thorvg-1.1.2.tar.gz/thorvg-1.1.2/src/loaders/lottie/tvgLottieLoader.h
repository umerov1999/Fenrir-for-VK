/*
 * Copyright (c) 2023 - 2026 ThorVG project. All rights reserved.

 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:

 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.

 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

#ifndef _TVG_LOTTIE_LOADER_H_
#define _TVG_LOTTIE_LOADER_H_

#include "tvgCommon.h"
#include "tvgInlist.h"
#include "tvgLoader.h"
#include "tvgTaskScheduler.h"
#include "thorvg_lottie.h"

struct LottieComposition;
struct LottieBuilder;
struct LottieProperty;
struct LottieSlot;


struct LottieCustomSlot
{
    INLIST_ITEM(LottieCustomSlot);

    struct Pair
    {
        LottieProperty* prop;  // New overriding property
        LottieSlot* target;    // Overriding target
    };
    Array<Pair> props;      // This has a list of the overriding target(LottieSlot) with a property to apply.
    uint32_t code;          // Slot source-code key

    LottieCustomSlot(uint32_t code) : code(code) {}
    ~LottieCustomSlot();
};

struct LottieLoader : AnimLoader, Task
{
    const char* content = nullptr;      //lottie file data
    uint32_t size = 0;                  //lottie data size
    float frameNo = 0.0f;               //current frame number
    float frameCnt = 0.0f;
    float frameRate = 0.0f;

    LottieBuilder* builder;
    LottieComposition* comp = nullptr;
    Inlist<LottieCustomSlot> slots;     //user custom slot list
    uint32_t curSlot = 0;               //current applied slotcode

    Key key;
    char* dirName = nullptr;            //base resource directory
    bool build = true;                  //require building the lottie scene

    LottieLoader();
    ~LottieLoader();

    Result open(const char* path, const LoaderOps& ops) override;
    Result open(const char* data, uint32_t size, const LoaderOps& ops) override;
    bool resize(Paint* paint, float w, float h) override;
    bool read() override;
    Paint* paint() override;

    //Slot Methods
    uint32_t gen(const char* slot, bool byDefault = false);
    bool apply(uint32_t slotcode, bool byDefault = false);
    bool del(uint32_t slotcode, bool byDefault = false);

    //Frame Controls
    bool frame(float no) override;
    float totalFrame() override;
    float curFrame() override;
    float duration() override;
    bool sync() override;

    //Marker Supports
    uint32_t markersCnt();
    const char* markers(uint32_t index, float* begin = nullptr, float* end = nullptr);
    bool segment(const char* marker, float& begin, float& end);
    Result segment(float begin, float end) override;

    float shorten(float frameNo);  //Reduce the accuracy for performance
    bool tween(float from, float to, float progress);
    bool tweenTo(float to);
    bool tween(float progress);
    bool quality(uint8_t value);
    void resolver(std::function<void(const tvg::LottieAudioResolver&, void*)> func, void* data);
    void volume(float value);

private:
    bool ready();
    Result header();
    void clear();
    float startFrame();
    void run(unsigned tid) override;
    void release();
    bool prepare();
};

#endif //_TVG_LOTTIELOADER_H_
